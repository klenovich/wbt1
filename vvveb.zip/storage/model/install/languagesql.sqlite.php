<?php 

/*
Generated from /home/www/vvveb/vvveb/install/sql/sqlite//language.sql
*/
namespace Vvveb\Sql;

use \Vvveb\System\Db;

class LanguageSQL {

	private $db;
	
	public function __construct(){
		$this->db = Db::getInstance();
	}

	
	
	function getAll($params = array()) {
		$paramTypes = array('status' => 'i', 'start' => 'i', 'limit' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'SELECT *, code as array_key
			FROM language as language WHERE 1 = 1
			
					';
		if (isset($params['status'])) {
			$sql .= '
				AND status = :status
			';
			} //end if
			
			$sql .= '
			
			ORDER BY status DESC
			
					';
		if (isset($params['limit'])) { 
		$sql .= $this->db->sqlLimit(':start', ':limit');
			} //end if
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['language'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = $stmt['language'];
			/*
			if ($stmt['language']) {
				if (method_exists($stmt['language'], 'get_result')) {
					$result = $stmt['language']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['language']);
				}
			}
			*/

			if (!empty('code')) {
				if ($result)
				//while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
				while ($row = $this->db->fetchArray($result)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('language' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['language'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('language' == '_') {
					$value = 
	$this->db->fetchAll($result)
;
					if (is_array($value)) {
						$results = $results + $value;
					} else {
						$results = $value;
					}
				} else  {
					$results['language'] = 
	$this->db->fetchAll($result)
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'SELECT count(*) FROM (
					
							'; 
		$sql .= $this->db->sqlCount($prevSql, 'language.language_id', $this->db->prefix . 'language'); 
		$sql .= ' ) as count';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['count'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = $stmt['count'];
			/*
			if ($stmt['count']) {
				if (method_exists($stmt['count'], 'get_result')) {
					$result = $stmt['count']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['count']);
				}
			}
			*/

			if (!empty('')) {
				if ($result)
				//while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
				while ($row = $this->db->fetchArray($result)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('count' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['count'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('count' == '_') {
					$value = 
		$this->db->fetchOne($result)
;
					if (is_array($value)) {
						$results = $results + $value;
					} else {
						$results = $value;
					}
				} else  {
					$results['count'] = 
		$this->db->fetchOne($result)
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function get($params = array()) {
		$paramTypes = array('language_id' => 'i', 'code' => 's');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'SELECT *, language_id
			FROM language as _ 
		WHERE 1 = 1 
			
					';
		if (isset($params['language_id'])) {
			$sql .= '
				AND language_id = :language_id
			';
			} //end if
		if (isset($params['code'])) {
			$sql .= '
				AND code = :code
			';
			} //end if
			
			$sql .= '

		LIMIT 1';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['_'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = $stmt['_'];
			/*
			if ($stmt['_']) {
				if (method_exists($stmt['_'], 'get_result')) {
					$result = $stmt['_']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['_']);
				}
			}
			*/

			if (!empty('')) {
				if ($result)
				//while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
				while ($row = $this->db->fetchArray($result)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('_' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['_'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('_' == '_') {
					$value = 
	$this->db->fetchArray($result)
;
					if (is_array($value)) {
						$results = $results + $value;
					} else {
						$results = $value;
					}
				} else  {
					$results['_'] = 
	$this->db->fetchArray($result)
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function add($params = array()) {
		$paramTypes = array('language' => 'a');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = '';

		$filterArray = array (
  'language_id' => 
  array (
    't' => 'INTEGER',
    'd' => NULL,
    'n' => true,
  ),
  'name' => 
  array (
    't' => 'TEXT',
    'd' => NULL,
    'n' => true,
  ),
  'code' => 
  array (
    't' => 'TEXT',
    'd' => NULL,
    'n' => true,
  ),
  'locale' => 
  array (
    't' => 'TEXT',
    'd' => NULL,
    'n' => true,
  ),
  'sort_order' => 
  array (
    't' => 'INTEGER',
    'd' => '0',
    'n' => true,
  ),
  'status' => 
  array (
    't' => 'TINYINT',
    'd' => NULL,
    'n' => true,
  ),
  'default' => 
  array (
    't' => 'TINYINT',
    'd' => '0',
    'n' => true,
  ),
);


		$params['language_data']= $this->db->filter($params['language'], $filterArray,false);

		$sql = '';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt[''] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = $stmt[''];
			/*
			if ($stmt['']) {
				if (method_exists($stmt[''], 'get_result')) {
					$result = $stmt['']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['']);
				}
			}
			*/

			if (!empty('')) {
				if ($result)
				//while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
				while ($row = $this->db->fetchArray($result)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results[''][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('' == '_') {
					$value = 
	$this->db->insert_id
;
					if (is_array($value)) {
						$results = $results + $value;
					} else {
						$results = $value;
					}
				} else  {
					$results[''] = 
	$this->db->insert_id
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'INSERT INTO language 
			
			( 		';
		$q = $this->db->quote;
		$sql .= $q . implode("$q,$q", array_keys($params['language_data'])); 
		$sql .= $q . '  )
			
	  	VALUES ( :language_data )';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['language'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = $stmt['language'];
			/*
			if ($stmt['language']) {
				if (method_exists($stmt['language'], 'get_result')) {
					$result = $stmt['language']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['language']);
				}
			}
			*/

			if (!empty('')) {
				if ($result)
				//while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
				while ($row = $this->db->fetchArray($result)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('language' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['language'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('language' == '_') {
					$value = 
	$this->db->insert_id
;
					if (is_array($value)) {
						$results = $results + $value;
					} else {
						$results = $value;
					}
				} else  {
					$results['language'] = 
	$this->db->insert_id
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function delete($params = array()) {
		$paramTypes = array('language_id' => 'a');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'DELETE FROM language WHERE language_id IN (:language_id)';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['language'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = $stmt['language'];
			/*
			if ($stmt['language']) {
				if (method_exists($stmt['language'], 'get_result')) {
					$result = $stmt['language']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['language']);
				}
			}
			*/

			if (!empty('')) {
				if ($result)
				//while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
				while ($row = $this->db->fetchArray($result)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('language' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['language'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('language' == '_') {
					$value = 
	$this->db->affected_rows
;
					if (is_array($value)) {
						$results = $results + $value;
					} else {
						$results = $value;
					}
				} else  {
					$results['language'] = 
	$this->db->affected_rows
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function edit($params = array()) {
		$paramTypes = array('language' => 'a', 'language_id' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = '';

		$filterArray = array (
  'language_id' => 
  array (
    't' => 'INTEGER',
    'd' => NULL,
    'n' => true,
  ),
  'name' => 
  array (
    't' => 'TEXT',
    'd' => NULL,
    'n' => true,
  ),
  'code' => 
  array (
    't' => 'TEXT',
    'd' => NULL,
    'n' => true,
  ),
  'locale' => 
  array (
    't' => 'TEXT',
    'd' => NULL,
    'n' => true,
  ),
  'sort_order' => 
  array (
    't' => 'INTEGER',
    'd' => '0',
    'n' => true,
  ),
  'status' => 
  array (
    't' => 'TINYINT',
    'd' => NULL,
    'n' => true,
  ),
  'default' => 
  array (
    't' => 'TINYINT',
    'd' => '0',
    'n' => true,
  ),
);


		$params['language']= $this->db->filter($params['language'], $filterArray,false);

		$sql = '';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt[''] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = $stmt[''];
			/*
			if ($stmt['']) {
				if (method_exists($stmt[''], 'get_result')) {
					$result = $stmt['']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['']);
				}
			}
			*/

			if (!empty('')) {
				if ($result)
				//while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
				while ($row = $this->db->fetchArray($result)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results[''][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('' == '_') {
					$value = 
	$this->db->affected_rows
;
					if (is_array($value)) {
						$results = $results + $value;
					} else {
						$results = $value;
					}
				} else  {
					$results[''] = 
	$this->db->affected_rows
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'UPDATE language 
			
			SET 		';
		
			list($_sql, $_params) = $this->db->expandList($params['language'], 'language');

			$sql .= ' ' . $_sql;

			if (is_array($_params)) $paramTypes = array_merge($paramTypes, $_params);

			$sql .= ' ' . ' 
			
		WHERE language_id = :language_id';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['language'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = $stmt['language'];
			/*
			if ($stmt['language']) {
				if (method_exists($stmt['language'], 'get_result')) {
					$result = $stmt['language']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['language']);
				}
			}
			*/

			if (!empty('')) {
				if ($result)
				//while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
				while ($row = $this->db->fetchArray($result)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('language' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['language'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('language' == '_') {
					$value = 
	$this->db->affected_rows
;
					if (is_array($value)) {
						$results = $results + $value;
					} else {
						$results = $value;
					}
				} else  {
					$results['language'] = 
	$this->db->affected_rows
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
}
