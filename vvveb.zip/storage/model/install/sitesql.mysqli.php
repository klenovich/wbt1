<?php 

/*
Generated from /home/www/vvveb/vvveb/install/sql/mysqli//site.sql
*/
namespace Vvveb\Sql;

use \Vvveb\System\Db;

class SiteSQL {

	private $db;
	
	public function __construct(){
		$this->db = Db::getInstance();
	}

	
	
	function getAll($params = array()) {
		$paramTypes = array('start' => 'i', 'limit' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'SELECT *, site_id as array_key
			FROM site as sites

				';
		if (isset($params['limit'])) { 
		$sql .= $this->db->sqlLimit(':start', ':limit');
			} //end if
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['sites'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['sites']) {
				if (method_exists($stmt['sites'], 'get_result')) {
					$result = $stmt['sites']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['sites']);
				}
			}
			

			if (!empty('site_id')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('sites' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['sites'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('sites' == '_') {
					if ($result) {
						$value = 
	$result->fetch_all(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['sites'] = 
	$result->fetch_all(MYSQLI_ASSOC)
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'SELECT count(*) FROM (
			
					'; 
		$sql .= $this->db->sqlCount($prevSql, 'sites.site_id', $this->db->prefix . 'site'); 
		$sql .= ' ) as count';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['count'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['count']) {
				if (method_exists($stmt['count'], 'get_result')) {
					$result = $stmt['count']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['count']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('count' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['count'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('count' == '_') {
					if ($result) {
						$value = 
	$result->fetch_array(MYSQLI_NUM)[0] ?? null
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['count'] = 
	$result->fetch_array(MYSQLI_NUM)[0] ?? null
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function getData($params = array()) {
		$paramTypes = array('site_id' => 'i', 'country_id' => 'i', 'language_id' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'SELECT 
			name,  country_id as array_key, 
			name as array_value
			
		FROM country as country_id WHERE status = 1';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['country_id'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['country_id']) {
				if (method_exists($stmt['country_id'], 'get_result')) {
					$result = $stmt['country_id']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['country_id']);
				}
			}
			

			if (!empty('country_id')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('name')) {
						$values = $row['array_value'];
					} 
				
					if ('country_id' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['country_id'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('country_id' == '_') {
					if ($result) {
						$value = 
	$result->fetch_all(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['country_id'] = 
	$result->fetch_all(MYSQLI_ASSOC)
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'SELECT 
			name,  region_id as array_key, 
			name as array_value
			
		FROM region as region_id WHERE country_id = :country_id AND status = 1';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['region_id'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['region_id']) {
				if (method_exists($stmt['region_id'], 'get_result')) {
					$result = $stmt['region_id']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['region_id']);
				}
			}
			

			if (!empty('region_id')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('name')) {
						$values = $row['array_value'];
					} 
				
					if ('region_id' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['region_id'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('region_id' == '_') {
					if ($result) {
						$value = 
	$result->fetch_all(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['region_id'] = 
	$result->fetch_all(MYSQLI_ASSOC)
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'SELECT 
			name,  language_id as array_key, 
			name as array_value
			
		FROM language as language_id WHERE status = 1';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['language_id'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['language_id']) {
				if (method_exists($stmt['language_id'], 'get_result')) {
					$result = $stmt['language_id']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['language_id']);
				}
			}
			

			if (!empty('language_id')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('name')) {
						$values = $row['array_value'];
					} 
				
					if ('language_id' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['language_id'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('language_id' == '_') {
					if ($result) {
						$value = 
	$result->fetch_all(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['language_id'] = 
	$result->fetch_all(MYSQLI_ASSOC)
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'SELECT 
			name,  currency_id as array_key, 
			name as array_value
			
		FROM currency as currency_id WHERE status = 1';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['currency_id'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['currency_id']) {
				if (method_exists($stmt['currency_id'], 'get_result')) {
					$result = $stmt['currency_id']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['currency_id']);
				}
			}
			

			if (!empty('currency_id')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('name')) {
						$values = $row['array_value'];
					} 
				
					if ('currency_id' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['currency_id'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('currency_id' == '_') {
					if ($result) {
						$value = 
	$result->fetch_all(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['currency_id'] = 
	$result->fetch_all(MYSQLI_ASSOC)
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'SELECT 
			name,  order_status_id as array_key, 
			name as array_value
			
		FROM order_status as order_status_id WHERE language_id = :language_id';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['order_status_id'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['order_status_id']) {
				if (method_exists($stmt['order_status_id'], 'get_result')) {
					$result = $stmt['order_status_id']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['order_status_id']);
				}
			}
			

			if (!empty('order_status_id')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('name')) {
						$values = $row['array_value'];
					} 
				
					if ('order_status_id' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['order_status_id'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('order_status_id' == '_') {
					if ($result) {
						$value = 
	$result->fetch_all(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['order_status_id'] = 
	$result->fetch_all(MYSQLI_ASSOC)
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'SELECT 
		
			*, weight_type_id.weight_type_id as array_key,
			weight_desc.name as array_value FROM weight_type as weight_type_id
			LEFT JOIN weight_type_content as weight_desc
				ON weight_type_id.weight_type_id = weight_desc.weight_type_id';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['weight_type_id'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['weight_type_id']) {
				if (method_exists($stmt['weight_type_id'], 'get_result')) {
					$result = $stmt['weight_type_id']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['weight_type_id']);
				}
			}
			

			if (!empty('weight_type_id')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('name')) {
						$values = $row['array_value'];
					} 
				
					if ('weight_type_id' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['weight_type_id'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('weight_type_id' == '_') {
					if ($result) {
						$value = 
	$result->fetch_all(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['weight_type_id'] = 
	$result->fetch_all(MYSQLI_ASSOC)
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'SELECT 
		
			*, length_type_id.length_type_id as array_key,
			length_desc.name as array_value FROM length_type as length_type_id
			LEFT JOIN length_type_content as length_desc
				ON length_type_id.length_type_id = length_desc.length_type_id';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['length_type_id'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['length_type_id']) {
				if (method_exists($stmt['length_type_id'], 'get_result')) {
					$result = $stmt['length_type_id']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['length_type_id']);
				}
			}
			

			if (!empty('length_type_id')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('name')) {
						$values = $row['array_value'];
					} 
				
					if ('length_type_id' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['length_type_id'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('length_type_id' == '_') {
					if ($result) {
						$value = 
	$result->fetch_all(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['length_type_id'] = 
	$result->fetch_all(MYSQLI_ASSOC)
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function get($params = array()) {
		$paramTypes = array('site_id' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'SELECT *
			FROM site as _ WHERE site_id = :site_id';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['_'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['_']) {
				if (method_exists($stmt['_'], 'get_result')) {
					$result = $stmt['_']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['_']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('_' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['_'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('_' == '_') {
					if ($result) {
						$value = 
	$result->fetch_array(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['_'] = 
	$result->fetch_array(MYSQLI_ASSOC)
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function add($params = array()) {
		$paramTypes = array('site' => 'a');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = '';

		$filterArray = array (
  'site_id' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'tinyint',
    'e' => 'auto_increment',
  ),
  'key' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'name' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'host' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'theme' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'template' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'settings' => 
  array (
    'd' => 'NULL',
    'n' => true,
    't' => 'text',
  ),
);


		$params['site_data']= $this->db->filter($params['site'], $filterArray,false);

		$sql = '';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt[''] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['']) {
				if (method_exists($stmt[''], 'get_result')) {
					$result = $stmt['']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results[''][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('' == '_') {
					if ($result) {
						$value = 
	$this->db->insert_id
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results[''] = 
	$this->db->insert_id
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'INSERT INTO site 
			
			( 		';
		$q = $this->db->quote;
		$sql .= $q . implode("$q,$q", array_keys($params['site_data'])); 
		$sql .= $q . '  )
			
	  	VALUES ( :site_data )';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['site'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['site']) {
				if (method_exists($stmt['site'], 'get_result')) {
					$result = $stmt['site']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['site']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('site' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['site'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('site' == '_') {
					if ($result) {
						$value = 
	$this->db->insert_id
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['site'] = 
	$this->db->insert_id
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function edit($params = array()) {
		$paramTypes = array('site' => 'a', 'site_id' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = '';

		$filterArray = array (
  'site_id' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'tinyint',
    'e' => 'auto_increment',
  ),
  'key' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'name' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'host' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'theme' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'template' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'settings' => 
  array (
    'd' => 'NULL',
    'n' => true,
    't' => 'text',
  ),
);


		$params['site_data']= $this->db->filter($params['site'], $filterArray,false);

		$sql = '';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt[''] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['']) {
				if (method_exists($stmt[''], 'get_result')) {
					$result = $stmt['']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results[''][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('' == '_') {
					if ($result) {
						$value = 
	$this->db->insert_id
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results[''] = 
	$this->db->insert_id
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'UPDATE site 
			
			SET 		';
		
			list($_sql, $_params) = $this->db->expandList($params['site_data'], 'site_data');

			$sql .= ' ' . $_sql;

			if (is_array($_params)) $paramTypes = array_merge($paramTypes, $_params);

			$sql .= ' ' . ' 
			
		WHERE site_id = :site_id';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['site'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['site']) {
				if (method_exists($stmt['site'], 'get_result')) {
					$result = $stmt['site']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['site']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('site' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['site'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('site' == '_') {
					if ($result) {
						$value = 
	$this->db->insert_id
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['site'] = 
	$this->db->insert_id
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
}
