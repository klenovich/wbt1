<?php 

/*
Generated from /home/www/vvveb/vvveb/install/sql/mysqli//admin.sql
*/
namespace Vvveb\Sql;

use \Vvveb\System\Db;

class AdminSQL {

	private $db;
	
	public function __construct(){
		$this->db = Db::getInstance();
	}

	
	
	function getAll($params = array()) {
		$paramTypes = array('start' => 'i', 'limit' => 'i', 'status' => 'i', 'search' => 's', 'email' => 's', 'phone_number' => 's');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'SELECT * FROM admin AS admin WHERE 1 = 1 


            		';
		if (isset($params['status']) AND !empty($params['status'])) {
			$sql .= ' 
				AND admin.status = :status 
        	';
			} //end if
		if (isset($params['email']) AND !empty($params['email'])) {
			$sql .= ' 
				AND admin.email = :email 
        	';
			} //end if
		if (isset($params['phone_number']) AND !empty($params['phone_number'])) {
			$sql .= ' 
				AND admin.phone_number = :phone_number 
        	';
			} //end if
		if (isset($params['search']) AND !empty($params['search'])) {
			$sql .= ' 
				AND admin.username LIKE CONCAT(\'%\',:search,\'%\') || admin.first_name LIKE CONCAT(\'%\',:search,\'%\') || admin.last_name LIKE CONCAT(\'%\',:search,\'%\')
        	';
			} //end if
		if (isset($params['limit'])) { 
		$sql .= $this->db->sqlLimit(':start', ':limit');
			} //end if
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['admin'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['admin']) {
				if (method_exists($stmt['admin'], 'get_result')) {
					$result = $stmt['admin']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['admin']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('admin' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['admin'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('admin' == '_') {
					if ($result) {
						$value = 
	$result->fetch_all(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['admin'] = 
	$result->fetch_all(MYSQLI_ASSOC)
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'SELECT count(*) FROM (
			
					'; 
		$sql .= $this->db->sqlCount($prevSql, 'admin.user_id', $this->db->prefix . 'user'); 
		$sql .= ' ) as count';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['count'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['count']) {
				if (method_exists($stmt['count'], 'get_result')) {
					$result = $stmt['count']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['count']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('count' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['count'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('count' == '_') {
					if ($result) {
						$value = 
	$result->fetch_array(MYSQLI_NUM)[0] ?? null
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['count'] = 
	$result->fetch_array(MYSQLI_NUM)[0] ?? null
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function get($params = array()) {
		$paramTypes = array('username' => 's', 'email' => 's', 'token' => 's', 'admin_id' => 'i', 'status' => 'i', 'role_id' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'SELECT _.*, role.permissions FROM admin AS _ 
			LEFT JOIN role ON (_.role_id = role.role_id)
		
		WHERE 1 = 1

        		';
		if (isset($params['username'])) {
			$sql .= ' 
		AND _.username = :username 
       	';
			} //end if
		if (isset($params['email'])) {
			$sql .= ' 
		AND _.email = :email 
        ';
			} //end if
		if (isset($params['admin_id'])) {
			$sql .= ' 
			AND _.admin_id = :admin_id 
       	';
			} //end if
		if (isset($params['status'])) {
			$sql .= ' 
			AND _.status = :status 
       	';
			} //end if
		if (isset($params['token'])) {
			$sql .= ' 
			AND _.token = :token 
       	';
			} //end if
		if (isset($params['role_id'])) {
			$sql .= ' 
			AND _.role_id = :role_id 
       	';
			} //end if
			
			$sql .= '	
			
		LIMIT 1';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['_'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['_']) {
				if (method_exists($stmt['_'], 'get_result')) {
					$result = $stmt['_']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['_']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('_' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['_'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('_' == '_') {
					if ($result) {
						$value = 
	$result->fetch_array(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['_'] = 
	$result->fetch_array(MYSQLI_ASSOC)
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function add($params = array()) {
		$paramTypes = array('admin' => 'a');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = '';

		$filterArray = array (
  'admin_id' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'int',
    'e' => 'auto_increment',
  ),
  'username' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'first_name' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'last_name' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'password' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'email' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'phone_number' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'url' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'display_name' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'role_id' => 
  array (
    'd' => 'NULL',
    'n' => true,
    't' => 'int',
  ),
  'status' => 
  array (
    'd' => '0',
    'n' => false,
    't' => 'int',
  ),
  'token' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'created_at' => 
  array (
    'd' => 'current_timestamp()',
    'n' => false,
    't' => 'datetime',
  ),
  'updated_at' => 
  array (
    'd' => 'current_timestamp()',
    'n' => false,
    't' => 'datetime',
  ),
);


		$params['admin']= $this->db->filter($params['admin'], $filterArray,false);

		$sql = '';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt[''] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['']) {
				if (method_exists($stmt[''], 'get_result')) {
					$result = $stmt['']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results[''][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('' == '_') {
					if ($result) {
						$value = 
	$this->db->insert_id
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results[''] = 
	$this->db->insert_id
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'INSERT INTO admin 
			
			( 		';
		$q = $this->db->quote;
		$sql .= $q . implode("$q,$q", array_keys($params['admin'])); 
		$sql .= $q . '  )
			
	  	VALUES ( ';

		 list($_sql, $_params) = $this->db->expandArray($params['admin'], 'admin');

		$sql .= $_sql;

		if (is_array($_params)) $paramTypes = array_merge($paramTypes, $_params);

		$sql .= ' )';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['admin'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['admin']) {
				if (method_exists($stmt['admin'], 'get_result')) {
					$result = $stmt['admin']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['admin']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('admin' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['admin'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('admin' == '_') {
					if ($result) {
						$value = 
	$this->db->insert_id
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['admin'] = 
	$this->db->insert_id
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function edit($params = array()) {
		$paramTypes = array('user' => 's', 'email' => 's', 'admin_id' => 'i', 'admin' => 'a', 'role_id' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = '';

		$filterArray = array (
  'admin_id' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'int',
    'e' => 'auto_increment',
  ),
  'username' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'first_name' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'last_name' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'password' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'email' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'phone_number' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'url' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'display_name' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'role_id' => 
  array (
    'd' => 'NULL',
    'n' => true,
    't' => 'int',
  ),
  'status' => 
  array (
    'd' => '0',
    'n' => false,
    't' => 'int',
  ),
  'token' => 
  array (
    'd' => '',
    'n' => false,
    't' => 'varchar',
  ),
  'created_at' => 
  array (
    'd' => 'current_timestamp()',
    'n' => false,
    't' => 'datetime',
  ),
  'updated_at' => 
  array (
    'd' => 'current_timestamp()',
    'n' => false,
    't' => 'datetime',
  ),
);


		$params['admin']= $this->db->filter($params['admin'], $filterArray,false);

		$sql = '';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt[''] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['']) {
				if (method_exists($stmt[''], 'get_result')) {
					$result = $stmt['']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results[''][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('' == '_') {
					if ($result) {
						$value = 
	$this->db->affected_rows
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results[''] = 
	$this->db->affected_rows
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'UPDATE admin 
			
			SET 		';
		
			list($_sql, $_params) = $this->db->expandList($params['admin'], 'admin');

			$sql .= ' ' . $_sql;

			if (is_array($_params)) $paramTypes = array_merge($paramTypes, $_params);

			$sql .= ' ' . ' 
			
		WHERE 

        		';
		if (isset($params['email'])) {
			$sql .= ' 
			email = :email 
        ';
			} //end if
		if (isset($params['admin_id'])) {
			$sql .= ' 
			admin_id = :admin_id 
        ';
			} //end if
		if (isset($params['username'])) {
			$sql .= ' 
			username = :username 
       	 ';
			} //end if
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['admin'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['admin']) {
				if (method_exists($stmt['admin'], 'get_result')) {
					$result = $stmt['admin']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['admin']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('admin' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['admin'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('admin' == '_') {
					if ($result) {
						$value = 
	$this->db->affected_rows
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['admin'] = 
	$this->db->affected_rows
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function delete($params = array()) {
		$paramTypes = array('admin_id' => 'a');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'DELETE FROM admin WHERE admin_id IN (:admin_id)';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['admin'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['admin']) {
				if (method_exists($stmt['admin'], 'get_result')) {
					$result = $stmt['admin']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['admin']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('admin' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['admin'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('admin' == '_') {
					if ($result) {
						$value = 
	$this->db->affected_rows
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['admin'] = 
	$this->db->affected_rows
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function setRole($params = array()) {
		$paramTypes = array('admin_id' => 'i', 'role' => 's', 'role_id' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'UPDATE admin 
			
			SET  
            
            		';
		if (isset($params['role_id'])) {
			$sql .= ' 
				role_id = :role_id 
        	';
			} //end if
		if (isset($params['role'])) {
			$sql .= ' 
				role_id = (SELECT role_id FROM roles WHERE name = :role)
        	';
			} //end if
			
			$sql .= '		

			
		WHERE admin_id = :admin_id';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['admin'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['admin']) {
				if (method_exists($stmt['admin'], 'get_result')) {
					$result = $stmt['admin']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['admin']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('admin' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['admin'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('admin' == '_') {
					if ($result) {
						$value = 
	$this->db->insert_id
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['admin'] = 
	$this->db->insert_id
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
}
