<?php 

/*
Generated from /home/www/vvveb/vvveb/install/sql/mysqli//role.sql
*/
namespace Vvveb\Sql;

use \Vvveb\System\Db;

class RoleSQL {

	private $db;
	
	public function __construct(){
		$this->db = Db::getInstance();
	}

	
	
	function getAll($params = array()) {
		$paramTypes = array('start' => 'i', 'limit' => 'i', 'status' => 'i', 'search' => 's', 'post_id' => 'a');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'SELECT * FROM role WHERE 1 = 1 

					';
		if (isset($params['limit'])) { 
		$sql .= $this->db->sqlLimit(':start', ':limit');
			} //end if
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['role'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['role']) {
				if (method_exists($stmt['role'], 'get_result')) {
					$result = $stmt['role']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['role']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('role' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['role'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('role' == '_') {
					if ($result) {
						$value = 
	$result->fetch_all(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['role'] = 
	$result->fetch_all(MYSQLI_ASSOC)
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'SELECT count(*) FROM (
			
					'; 
		$sql .= $this->db->sqlCount($prevSql, 'roles.user_id', $this->db->prefix . 'user'); 
		$sql .= ' ) as count';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['count'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['count']) {
				if (method_exists($stmt['count'], 'get_result')) {
					$result = $stmt['count']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['count']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('count' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['count'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('count' == '_') {
					if ($result) {
						$value = 
	$result->fetch_array(MYSQLI_NUM)[0] ?? null
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['count'] = 
	$result->fetch_array(MYSQLI_NUM)[0] ?? null
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function get($params = array()) {
		$paramTypes = array('role_id' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'SELECT * FROM role AS _ 
			WHERE _.role_id = :role_id 
		LIMIT 1';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['_'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['_']) {
				if (method_exists($stmt['_'], 'get_result')) {
					$result = $stmt['_']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['_']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('_' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['_'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('_' == '_') {
					if ($result) {
						$value = 
	$result->fetch_array(MYSQLI_ASSOC)
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['_'] = 
	$result->fetch_array(MYSQLI_ASSOC)
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function add($params = array()) {
		$paramTypes = array('role' => 'a');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = '';

		$filterArray = array (
  'role_id' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'int',
    'e' => 'auto_increment',
  ),
  'name' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'display_name' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'permissions' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'text',
  ),
);


		$params['role']= $this->db->filter($params['role'], $filterArray,false);

		$sql = '';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt[''] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['']) {
				if (method_exists($stmt[''], 'get_result')) {
					$result = $stmt['']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results[''][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('' == '_') {
					if ($result) {
						$value = 
	$this->db->insert_id
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results[''] = 
	$this->db->insert_id
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'INSERT INTO role 
			
			( 		';
		$q = $this->db->quote;
		$sql .= $q . implode("$q,$q", array_keys($params['role'])); 
		$sql .= $q . '  )
			
	  	VALUES ( ';

		 list($_sql, $_params) = $this->db->expandArray($params['role'], 'role');

		$sql .= $_sql;

		if (is_array($_params)) $paramTypes = array_merge($paramTypes, $_params);

		$sql .= ' )';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['role'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['role']) {
				if (method_exists($stmt['role'], 'get_result')) {
					$result = $stmt['role']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['role']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('role' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['role'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('role' == '_') {
					if ($result) {
						$value = 
	$this->db->insert_id
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['role'] = 
	$this->db->insert_id
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function edit($params = array()) {
		$paramTypes = array('role_id' => 'i', 'role' => 'a');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = '';

		$filterArray = array (
  'role_id' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'int',
    'e' => 'auto_increment',
  ),
  'name' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'display_name' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'varchar',
  ),
  'permissions' => 
  array (
    'd' => NULL,
    'n' => false,
    't' => 'text',
  ),
);


		$params['role']= $this->db->filter($params['role'], $filterArray,false);

		$sql = '';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt[''] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['']) {
				if (method_exists($stmt[''], 'get_result')) {
					$result = $stmt['']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results[''][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('' == '_') {
					if ($result) {
						$value = 
	$this->db->affected_rows
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results[''] = 
	$this->db->affected_rows
;
				}
			}
		}
		

		
		$prevSql = $sql ?? '';
		$sql = 'UPDATE role 
			
			SET 		';
		
			list($_sql, $_params) = $this->db->expandList($params['role'], 'role');

			$sql .= ' ' . $_sql;

			if (is_array($_params)) $paramTypes = array_merge($paramTypes, $_params);

			$sql .= ' ' . ' 
			
		WHERE role_id = :role_id';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['role'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['role']) {
				if (method_exists($stmt['role'], 'get_result')) {
					$result = $stmt['role']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['role']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('role' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['role'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('role' == '_') {
					if ($result) {
						$value = 
	$this->db->affected_rows
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['role'] = 
	$this->db->affected_rows
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
	
	function setRole($params = array()) {
		$paramTypes = array('role_id' => 'i', 'role' => 's', 'role_id' => 'i');

		$results = [];
		$stmt = [];

		
		
		$prevSql = $sql ?? '';
		$sql = 'UPDATE role 
			
			SET  
            
            		';
		if (isset($params['role_id'])) {
			$sql .= ' 
				role_id = :role_id 
        	';
			} //end if
		if (isset($params['role'])) {
			$sql .= ' 
				role_id = (SELECT role_id FROM roles WHERE name = :role)
        	';
			} //end if
			
			$sql .= '		

			
		WHERE role_id = :role_id';
		$sql = trim($sql);
			
		if ($sql) {
			$stmt['role'] = $this->db->execute($sql, $params, $paramTypes);
			
			$result = false;

			if ($stmt['role']) {
				if (method_exists($stmt['role'], 'get_result')) {
					$result = $stmt['role']->get_result();
				} else 	{
					$result = $this->db->get_result($stmt['role']);
				}
			}
			

			if (!empty('')) {
				if ($result)
				while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
					$values = $row;
					if (!empty('')) {
						$values = $row['array_value'];
					} 
				
					if ('role' == '_') {
						$results[$row['array_key']] = $values;
					} else {
						$results['role'][$row['array_key']] = $values;
						
					}
				}
			} else {
				if ('role' == '_') {
					if ($result) {
						$value = 
	$this->db->insert_id
;
					} else {
						$value = null;
					}
					
					if ($value) {
						if (is_array($value)) {
							$results = $results + $value;
						} else {
							$results = $value;
						}
					}
				} else  {
					$results['role'] = 
	$this->db->insert_id
;
				}
			}
		}
		


		if ($results)
		return $results;
	}		
	
	
}
