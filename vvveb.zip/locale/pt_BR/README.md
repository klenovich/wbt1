<p align="center">
  <img src="https://www.vvveb.com/admin/themes/default/img/biglogo.png" alt="Vvveb">
</p>
<p align="center">
  <a href="https://www.vvveb.com">Website</a> |
  <a href="https://www.vvveb.com/page/contribute#language">Language list</a> |
  <a href="https://twitter.com/vvvebcms">Twitter</a> 
</p>

# Vvveb Brazilian Portuguese Language (pt_BR)

Vvveb CMS translation for Brazilian Portuguese language

---

Vvveb uses [gettext](https://https://www.gnu.org/software/gettext/manual/gettext.html) for multi language translations

Edit the [translation file](/LC_MESSAGES/vvveb.po) and save or submit your changes to this repository

For easier editing you can use a text editor like [Poedit](https://poedit.net/) 

### Contributors

[givanz](https://github.com/givanz)

### License

CC0 1.0 Universal
