# Gravatar Vvveb plugin

Show gravatar images on comments for users that don't have avatars set.

👉🏻 [Plugin page](https://plugins.vvveb.com/product/gravatar) 👉🏻 [Download](https://github.com/Vvveb/gravatar/archive/main.zip)

| [![](https://plugins.vvveb.com/media/plugins/gravatar/gravatar-1.png)](https://plugins.vvveb.com/media/plugins/gravatar/gravatar-1.png) | [![](https://plugins.vvveb.com/media/plugins/gravatar/gravatar-2.png)](https://plugins.vvveb.com/media/plugins/gravatar/gravatar-2.png) |
|:---:|:---:|

## Install

Upload plugin zip to your Vvveb dashboard `admin / plugins` page or unzip to plugins folder.

## License

Copyright (c) [Vvveb](https://www.vvveb.com)

Released under the [GPL 3](https://github.com/Vvveb/gravatar/blob/main/LICENSE) license.
