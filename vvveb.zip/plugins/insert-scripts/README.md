# Insert scripts Vvveb plugin

Insert footer and header scripts such as analytics or widgets.

Settings are saved per site for multi site setups.

👉🏻 [Plugin page](https://plugins.vvveb.com/product/insert-scripts) 👉🏻 [Download](https://github.com/Vvveb/insert-scripts/archive/main.zip)

| [![](https://plugins.vvveb.com/media/plugins/insert-scripts/insert-scripts-1.png)](https://plugins.vvveb.com/media/plugins/insert-scripts/insert-scripts-1.png) |
|:---:|

## Install

From your Vvveb dashboard `admin / plugins` page upload plugin zip.

## License

Copyright (c) [Vvveb](https://www.vvveb.com)

Released under the [GPL 3](https://github.com/Vvveb/insert-scripts/blob/main/LICENSE) license.

