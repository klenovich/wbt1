# Ask ChatGPT Vvveb plugin

Add ChatGPT prompt toolbar button to content editor on post and product edit page.

👉🏻 [Plugin page](https://plugins.vvveb.com/product/chatgpt) 👉🏻 [Download](https://github.com/Vvveb/chatgpt/archive/main.zip)

| [![](https://plugins.vvveb.com/media/plugins/chatgpt/chatgpt-1.png)](https://plugins.vvveb.com/media/plugins/chatgpt/chatgpt-1.png) | [![](https://plugins.vvveb.com/media/plugins/chatgpt/chatgpt-2.png)](https://plugins.vvveb.com/media/plugins/chatgpt/chatgpt-2.png) |
|:---:|:---:|

## Install

Upload plugin zip to your Vvveb dashboard `admin / plugins` page or unzip to plugins folder.

## License

Copyright (c) [Vvveb](https://www.vvveb.com)

Released under the [GPL 3](https://github.com/Vvveb/chatgpt/blob/main/LICENSE) license.
