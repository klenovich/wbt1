# DiceBear Vvveb plugin

Show dicebear avatars on comments for users that don't have avatars set.

👉🏻 [Plugin page](https://plugins.vvveb.com/product/dicebear) 👉🏻 [Download](https://github.com/Vvveb/dicebear/archive/main.zip)

| [![](https://plugins.vvveb.com/media/plugins/dicebear/dicebear-1.png)](https://plugins.vvveb.com/media/plugins/dicebear/dicebear-1.png) | [![](https://plugins.vvveb.com/media/plugins/dicebear/dicebear-2.png)](https://plugins.vvveb.com/media/plugins/dicebear/dicebear-2.png) |
|:---:|:---:|

## Install

Upload plugin zip to your Vvveb dashboard `admin / plugins` page or unzip to plugins folder.

## License

Copyright (c) [Vvveb](https://www.vvveb.com)

Released under the [GPL 3](https://github.com/Vvveb/dicebear/blob/main/LICENSE) license.
