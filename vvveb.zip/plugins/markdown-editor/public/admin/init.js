const easymde = new EasyMDE({
	//element: document.getElementById('my-text-area'),
});
