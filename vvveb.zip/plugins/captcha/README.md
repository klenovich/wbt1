# Captcha Vvveb plugin

Show captcha on user signup/login/password reset and on post comment form, product review/question forms.

👉🏻 [Plugin page](https://plugins.vvveb.com/product/captcha) 👉🏻 [Download](https://github.com/Vvveb/captcha/archive/main.zip)

| [![](https://plugins.vvveb.com/media/plugins/captcha/captcha-1.png)](https://plugins.vvveb.com/media/plugins/captcha/captcha-1.png) | [![](https://plugins.vvveb.com/media/plugins/captcha/captcha-2.png)](https://plugins.vvveb.com/media/plugins/captcha/captcha-2.png) |
|:---:|:---:|

## Install

Upload plugin zip to your Vvveb dashboard `admin / plugins` page or unzip to plugins folder.

## License

Copyright (c) [Vvveb](https://www.vvveb.com)

Released under the [GPL 3](https://github.com/Vvveb/captcha/blob/main/LICENSE) license.
